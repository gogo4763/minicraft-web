
let scene = new THREE.Scene();
let camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
let renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

let raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2();
let blocks = [];

const blockSize = 1;
const blockGeo = new THREE.BoxGeometry(blockSize, blockSize, blockSize);

// Simple terrain color by height
function getBlockMaterial(y) {
  if (y < 1) return new THREE.MeshLambertMaterial({color: 0x664422}); // dirt
  if (y < 3) return new THREE.MeshLambertMaterial({color: 0x55aa55}); // grass
  return new THREE.MeshLambertMaterial({color: 0xaaaaaa}); // stone
}

// Generate simple terrain
let size = 16;
for (let x = -size; x <= size; x++) {
  for (let z = -size; z <= size; z++) {
    let height = Math.floor(Math.sin(x * 0.3) * Math.cos(z * 0.3) * 3 + 3); // pseudo noise
    for (let y = 0; y <= height; y++) {
      let mat = getBlockMaterial(y);
      let block = new THREE.Mesh(blockGeo, mat);
      block.position.set(x, y - 0.5, z);
      scene.add(block);
      blocks.push(block);
    }
  }
}

let light = new THREE.HemisphereLight(0xffffff, 0x444444, 1);
scene.add(light);
let directional = new THREE.DirectionalLight(0xffffff, 0.5);
scene.add(directional);

camera.position.set(0, 10, 20);
let controlsEnabled = false;
let isTouching = false;
let prevTouchX = 0, prevTouchY = 0;

function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}
animate();

function onTouchStart(e) {
  isTouching = true;
  prevTouchX = e.touches[0].clientX;
  prevTouchY = e.touches[0].clientY;
}

function onTouchMove(e) {
  if (!isTouching) return;
  let dx = e.touches[0].clientX - prevTouchX;
  let dy = e.touches[0].clientY - prevTouchY;
  camera.rotation.y -= dx * 0.005;
  camera.rotation.x -= dy * 0.005;
  camera.rotation.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, camera.rotation.x));
  prevTouchX = e.touches[0].clientX;
  prevTouchY = e.touches[0].clientY;
}

function onTouchEnd(e) {
  isTouching = false;
}

function onTap(e) {
  let x = (e.changedTouches[0].clientX / window.innerWidth) * 2 - 1;
  let y = -(e.changedTouches[0].clientY / window.innerHeight) * 2 + 1;
  mouse.set(x, y);
  raycaster.setFromCamera(mouse, camera);
  let intersects = raycaster.intersectObjects(blocks);
  if (intersects.length > 0) {
    let target = intersects[0].object;
    scene.remove(target);
    blocks.splice(blocks.indexOf(target), 1);
  } else {
    let vec = new THREE.Vector3(x, y, 0.5);
    vec.unproject(camera);
    let dir = vec.sub(camera.position).normalize();
    let pos = camera.position.clone().add(dir.multiplyScalar(5)).floor().addScalar(0.5);
    let newBlock = new THREE.Mesh(blockGeo, getBlockMaterial(pos.y));
    newBlock.position.copy(pos);
    scene.add(newBlock);
    blocks.push(newBlock);
  }
}

window.addEventListener('touchstart', onTouchStart);
window.addEventListener('touchmove', onTouchMove);
window.addEventListener('touchend', onTouchEnd);
window.addEventListener('touchcancel', onTouchEnd);
window.addEventListener('touchstart', function(e) { if (e.touches.length === 1) onTap(e); });
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
